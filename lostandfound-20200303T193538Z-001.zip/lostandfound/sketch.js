var serial;// variable to hold an instance of the serialport library
var portName = '/dev/cu.usbmodem14201';
var inData; // variable to hold the input data from Arduino
//var outMessage = 'H';

var locationData;

var button;
var button2;
var button3;
//var electric;

var sel;


function preload(){
  locationData = getCurrentPosition();
}

function setup() {
    
//soundFormats('mp3');
//electric = loadSound('sound/electric.mp3');
    
createCanvas(windowWidth, windowHeight);
  
    
  // put setup code here
console.log("Lost and Found");
  if(geoCheck() == true){
    //geolocation is available
    console.log("geolocation is available");
	}else{
    //error getting geolocaion
    console.log("error getting geolocation");
  }
  
  print(locationData.latitude);
  print(locationData.longitude);

 
  button = createButton('Locate it !');
  button.position(width/2.3, height/1.8);
  button.size(200,60);
  button.style("font-family","Comic Sans MS");
  button.style("font-size","20px");
  button.style("background-color","#ffcc00")
  button.style("color","#fff");
  button.mousePressed(locate);
    
  button2 = createButton('Found it !');
  button2.position(width/2.3, height/1.5);
  button2.size(200,60);
  button2.style("font-family","Comic Sans MS");
  button2.style("font-size","20px");
  button2.style("color","#6699FF");
  button2.mousePressed(cancel);
    
  button3 = createButton('View in Map');
  button3.position(width/2.3, height/1.3);
  button3.size(200,60);
  button3.style("font-family","Comic Sans MS");
  button3.style("font-size","20px");
  button3.style("color","#6699FF");
  button3.mousePressed(view);
  
  
//secel
  sel = createSelect();
  sel.position(width/2.1, height/3.8);
  sel.option('Phone');
  sel.option('Airpod left');
  sel.selected('Phone');
  sel.changed(mySelectEvent);
    
  serial = new p5.SerialPort();
  serial.list();
  serial.open("/dev/cu.usbmodem14201");
  serial.on('list', gotList);
  serial.on('data', gotData);
  serial.on('error', gotError);
  serial.on('open', gotOpen);
  
}

// We are connected and ready to go
function serverConnected() {
  console.log("Connected to Server");
}

// Got the list of ports
function gotList(thelist) {
  console.log("List of Serial Ports:");
  // theList is an array of their names
  for (var i = 0; i < thelist.length; i++) {
    // Display in the console
    console.log(i + " " + thelist[i]);
  }
}

// Connected to our serial device
function gotOpen() {
  console.log("Serial Port is Open");
}


// Ut oh, here is an error, let's log it
function gotError(theerror) {
  console.log(theerror);
}

function gotData() {
  var currentString = serial.readLine();
    
  console.log(currentString);
}



function draw() {
  // put drawing code here
  
  background(102, 153, 255);
  fill(255);
  textSize(36);
  textFont('Futura');
  text("Lost and Found", width/2.3,height/4.2);
      textSize(26);
  text("lat:" + " " + locationData.latitude, width/2.6, height/2.2);
  text("lng:" + " " + locationData.longitude, width/2.6, height/2.7);
}

function locate() {
  //window.location.href = "http://www.google.com";
  //  electric.play();
  serial.write('H');
}

function cancel() {
  //window.location.href = "http://www.google.com";
  serial.write('L');
}

function view() {
  window.location.href = "../lostandfound/geolocation/public/index.html";
}

function mySelectEvent() {
  let item = sel.value();
  //background(200);
  text('Let us find ' + item + '!', width/2.1, height/3.8+10);
}


