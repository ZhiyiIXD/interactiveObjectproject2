var serial;// variable to hold an instance of the serialport library
var portName = '/dev/cu.usbmodem14201';
var inData; // variable to hold the input data from Arduino

let song;

function setup() {
   song = loadSound('sound/electric.mp3');soundFormats('mp3', 'ogg');
}

 function mousePressed() {
  if (song.isPlaying()) {
    // .isPlaying() returns a boolean
    song.stop();
    background(255, 0, 0);
  } else {
    song.play();
    background(0, 255, 0);
  }
}
